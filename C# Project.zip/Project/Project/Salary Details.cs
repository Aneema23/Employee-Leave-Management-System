﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Salary_Details : Form
    {
        private string connectionString = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\USER\Desktop\LNBTI\Aneema\Project\Project\Employee Leave Management.mdf; Integrated Security = True;";
        private SqlDataAdapter dataAdapter;

        public Salary_Details()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string employeeID = txt_id.Text.Trim(); // Employee ID entered by the user
            if (string.IsNullOrEmpty(employeeID))
            {
                MessageBox.Show("Please enter an Employee ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Step 1: Fetch leave requests and count approved leaves
                    string query = "SELECT * FROM LeaveRequests WHERE EmployeeID = @EmployeeID";
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    adapter.SelectCommand.Parameters.AddWithValue("@EmployeeID", employeeID);

                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    int approvedCount = dataTable.AsEnumerable().Count(row => row.Field<string>("State") == "Approved");

                    // Display leave requests in DataGridView
                    dataGridView1.DataSource = dataTable;

                    // Step 2: Get the net salary of the employee (this can be hardcoded or fetched from another table)
                    decimal netSalary = 500000; // Example net salary

                    // Step 3: Calculate final salary
                    decimal deduction = approvedCount * 500; // Rs. 500 deduction per approved leave
                    decimal finalSalary = netSalary - deduction;

                    // Step 4: Save the data into the Salary table
                    string insertQuery = @"INSERT INTO Salary (EmployeeID, ApprovedLeaves, NetSalary, FinalSalary)
                                   VALUES (@EmployeeID, @ApprovedLeaves, @NetSalary, @FinalSalary)";
                    using (SqlCommand cmd = new SqlCommand(insertQuery, connection))
                    {
                        cmd.Parameters.AddWithValue("@EmployeeID", employeeID);
                        cmd.Parameters.AddWithValue("@ApprovedLeaves", approvedCount);
                        cmd.Parameters.AddWithValue("@NetSalary", netSalary);
                        cmd.Parameters.AddWithValue("@FinalSalary", finalSalary);

                        cmd.ExecuteNonQuery();
                    }

                    // Display success message and calculated salary
                    MessageBox.Show($"Salary calculated and saved successfully!\n" +
                                    $"Employee ID: {employeeID}\n" +
                                    $"Approved Leaves: {approvedCount}\n" +
                                    $"Net Salary: Rs. {netSalary}\n" +
                                    $"Final Salary: Rs. {finalSalary}",
                                    "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    // Optionally, clear fields or reset the form
                    txt_id.Clear();
                    lbl_approvedLeaves.Text = $"Approved Leaves: {approvedCount}";
                    lbl_finalSalary.Text = $"Final Salary: Rs. {finalSalary}";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            EmployeeDashboard form = new EmployeeDashboard();
            form.Show();
            this.Hide();
        }

        private void txt_id_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
