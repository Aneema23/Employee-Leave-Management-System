﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Leave_Request_Details : Form
    {
        private string connectionString = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\USER\Desktop\LNBTI\Aneema\Project\Project\Employee Leave Management.mdf; Integrated Security = True;";
        private SqlDataAdapter dataAdapter;
        public Leave_Request_Details()
        {
            InitializeComponent();

        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            EmployeeDashboard form = new EmployeeDashboard();
            form.Show();
            this.Hide();
        }

        private void LoadData(string employeeId = null)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();
                    string query;

                    // If an Employee ID is provided, filter by it
                    if (!string.IsNullOrEmpty(employeeId))
                    {
                        query = "SELECT * FROM LeaveRequests WHERE EmployeeID = @EmployeeID";
                    }
                    else
                    {
                        query = "SELECT * FROM LeaveRequests"; 
                    }

                    dataAdapter = new SqlDataAdapter(query, connection);

                    // Add parameter if filtering by Employee ID
                    if (!string.IsNullOrEmpty(employeeId))
                    {
                        dataAdapter.SelectCommand.Parameters.AddWithValue("@EmployeeID", employeeId);
                    }

                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    // Bind the DataTable to the DataGridView
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load data! Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a record to edit.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string employeeID = dataGridView1.SelectedRows[0].Cells["EmployeeID"].Value.ToString();
            string leaveType = dataGridView1.SelectedRows[0].Cells["LeaveType"].Value.ToString();
            DateTime startDate = Convert.ToDateTime(dataGridView1.SelectedRows[0].Cells["StartDate"].Value);
            DateTime endDate = Convert.ToDateTime(dataGridView1.SelectedRows[0].Cells["EndDate"].Value);

            txt_id.Text = employeeID;
            LeaveType.Text = leaveType;
            dtp_start.Value = startDate;
            dtp_end.Value = endDate;

            CalculateDuration(); // Update duration based on selected dates

            MessageBox.Show("Make changes and click Save to update the record.", "Edit Mode", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        private void btn_cancel_Click(object sender, EventArgs e)
        {
            txt_id.Clear();
            LeaveType.SelectedIndex = -1; 
            dtp_start.Value = DateTime.Now;
            dtp_end.Value = DateTime.Now;
            txt_time.Clear();   
            dataGridView1.DataSource = null;
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            string employeeID = txt_id.Text.Trim();

            if (string.IsNullOrEmpty(employeeID))
            {
                MessageBox.Show("Please enter an Employee ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            LoadData(employeeID);
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    string employeeID = dataGridView1.SelectedRows[0].Cells["EmployeeID"].Value.ToString();

                    DialogResult result = MessageBox.Show("Are you sure you want to delete this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            connection.Open();

                            string query = "DELETE FROM LeaveRequests WHERE EmployeeID = @EmployeeID";

                            using (SqlCommand cmd = new SqlCommand(query, connection))
                            {
                                cmd.Parameters.AddWithValue("@EmployeeID", employeeID);
                                int rowsAffected = cmd.ExecuteNonQuery();

                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show("Record deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                    // Clear the DataGridView after deletion
                                    dataGridView1.DataSource = null; // Clear the existing data
                                    LoadData(txt_id.Text.Trim());  // Reload only for the selected employee, or just load all if needed
                                }
                                else
                                {
                                    MessageBox.Show("Failed to delete record.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please select a record to delete.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to delete record! Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    string query = @"UPDATE LeaveRequests
                             SET LeaveType = @LeaveType, StartDate = @StartDate, EndDate = @EndDate, TimePeriod = @TimePeriod
                             WHERE EmployeeID = @EmployeeID";

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@EmployeeID", txt_id.Text.Trim());
                        cmd.Parameters.AddWithValue("@LeaveType", LeaveType.Text.Trim());
                        cmd.Parameters.AddWithValue("@StartDate", dtp_start.Value);
                        cmd.Parameters.AddWithValue("@EndDate", dtp_end.Value);
                        cmd.Parameters.AddWithValue("@TimePeriod", txt_time.Text.Trim());

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Record updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            LoadData(txt_id.Text.Trim()); 
                        }
                        else
                        {
                            MessageBox.Show("No record found to update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to update record! Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
}

        private void CalculateDuration()
        {
            DateTime startDate = dtp_start.Value;
            DateTime endDate = dtp_end.Value;

            if (endDate >= startDate)
            {
                TimeSpan duration = endDate - startDate;
                txt_time.Text = $"{duration.Days + 1}"; // Include both start and end dates
            }
            else
            {
                txt_time.Text = "0"; // Invalid duration
            }
        }

        private void dtp_start_ValueChanged(object sender, EventArgs e)
        {
            CalculateDuration();
        }

        private void dtp_end_ValueChanged(object sender, EventArgs e)
        {
            CalculateDuration();
        }
    }
}
