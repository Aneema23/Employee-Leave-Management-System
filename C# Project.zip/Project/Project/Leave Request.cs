﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Leave_Request : Form
    {
        private string connectionString = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\USER\Desktop\LNBTI\Aneema\Project\Project\Employee Leave Management.mdf; Integrated Security = True;";
        public Leave_Request()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            EmployeeDashboard form = new EmployeeDashboard();
            form.Show();
            this.Hide();
        }

        
        private void button1_Click(object sender, EventArgs e)
        {
            string employeeId = txt_id.Text;
            string leaveType = leave_type.SelectedItem?.ToString();
            DateTime startDate = dtp_Start.Value;
            DateTime endDate = dtp_End.Value;
            

            // Calculate time period
            int timePeriod = (endDate - startDate).Days + 1; // +1 to include the start date

            string state = "Pending";

            // Insert data into the database
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO LeaveRequests (EmployeeID, LeaveType, StartDate, EndDate, TimePeriod, State) VALUES (@EmployeeID, @LeaveType, @StartDate, @EndDate, @TimePeriod, @State)";
                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@EmployeeID", employeeId);
                cmd.Parameters.AddWithValue("@LeaveType", leaveType);
                cmd.Parameters.AddWithValue("@StartDate", startDate);
                cmd.Parameters.AddWithValue("@EndDate", endDate);
                cmd.Parameters.AddWithValue("@TimePeriod", timePeriod);
                cmd.Parameters.AddWithValue("@State", state);

                conn.Open();
                cmd.ExecuteNonQuery();
            }

            // Display the entered row in the DataGridView
            LoadLatestEntry();
        }

        private void LoadLatestEntry()
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "SELECT TOP 1 * FROM LeaveRequests ORDER BY RequiredID DESC";
                SqlDataAdapter adapter = new SqlDataAdapter(query, conn);
                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dataGridView1.DataSource = dt;
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            txt_id.Clear();
            leave_type.SelectedIndex = -1;
            dtp_Start.Value = DateTime.Now;
            dtp_End.Value = DateTime.Now;
            dataGridView1.DataSource = null;
        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void txt_time_TextChanged(object sender, EventArgs e)
        {

        }

        private void dtp_Start_ValueChanged(object sender, EventArgs e)
        {
            int timePeriod = (dtp_End.Value - dtp_Start.Value).Days + 1; // +1 to include the start date
            txt_time.Text = timePeriod.ToString();
        }

        private void dtp_End_ValueChanged(object sender, EventArgs e)
        {
            int timePeriod = (dtp_End.Value - dtp_Start.Value).Days + 1; // +1 to include the start date
            txt_time.Text = timePeriod.ToString();
        }
    }
}
