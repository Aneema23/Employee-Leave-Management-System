﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows.Forms;

namespace Project
{
    public partial class Leave_State : Form
    {
        private string connectionString = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\USER\Desktop\LNBTI\Aneema\Project\Project\Employee Leave Management.mdf; Integrated Security = True;";


        public Leave_State()
        {
            InitializeComponent();
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            EmployeeDashboard form = new EmployeeDashboard();
            form.Show();
            this.Hide();
        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            string employeeID = txt_id.Text.Trim(); 

            if (string.IsNullOrEmpty(employeeID))
            {
                MessageBox.Show("Please enter an Employee ID.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Query to get all leave requests for the given Employee ID
                    string query = "SELECT * FROM LeaveRequests WHERE EmployeeID = @EmployeeID";

                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    adapter.SelectCommand.Parameters.AddWithValue("@EmployeeID", employeeID);

                    DataTable dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    // Display the data in the DataGridView
                    Requeststate.DataSource = dataTable;

                    // Calculate counts for Pending and Approved requests
                    int pendingCount = dataTable.AsEnumerable().Count(row => row.Field<string>("State") == "Pending");
                    int approvedCount = dataTable.AsEnumerable().Count(row => row.Field<string>("State") == "Approved");

                    // Display the counts
                    lbl_pendingCount.Text = $"No of Pending Requests: {pendingCount}";
                    lbl_approvedCount.Text = $"No of Approved Requests: {approvedCount}";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to search data! Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
