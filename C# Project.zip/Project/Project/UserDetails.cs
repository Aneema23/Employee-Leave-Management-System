﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class UserDetails : Form
    {
        private string connectionString = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\USER\Desktop\LNBTI\Aneema\Project\Project\Employee Leave Management.mdf; Integrated Security = True;";

        public UserDetails()
        {
            InitializeComponent();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            string username = txt_user.Text;
            string password = txt_password.Text;
            string department = cmd_department.SelectedItem?.ToString();
            string role = cmd_role.SelectedItem?.ToString();



            // Validate department selection
            if (string.IsNullOrEmpty(department))
            {
                MessageBox.Show("Please select a department.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit if no department is selected
            }

            if (string.IsNullOrEmpty(role))
            {
                MessageBox.Show("Please select a role.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return; // Exit if no department is selected
            }


            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Users (Username, Password, Department, Role) VALUES (@Username, @Password, @Department, @Role)";
                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@Username", username);
                cmd.Parameters.AddWithValue("@Password", password);
                cmd.Parameters.AddWithValue("@Department", department);
                cmd.Parameters.AddWithValue("@Role", role);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
            MessageBox.Show("User details added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            txt_user.Text = "";
            txt_password.Text = "";
            cmd_department.SelectedIndex = -1;
            cmd_role.SelectedIndex = -1;
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            DepartmentHeadDashboard form = new DepartmentHeadDashboard();
            form.Show();
            this.Hide();
        }
    }
}
