﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class EmployeeDashboard : Form
    {
        public EmployeeDashboard()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }

        private void btn_apply_Click(object sender, EventArgs e)
        {
            Leave_Request form = new Leave_Request();
            form.Show();
            this.Hide();
        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            Leave_Request_Details form = new Leave_Request_Details();
            form.Show();
            this.Hide();
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
        
        }

        private void btn_check_Click(object sender, EventArgs e)
        {
            Leave_State form = new Leave_State();
            form.Show();
            this.Hide();
        }

        private void btn_view_Click(object sender, EventArgs e)
        {
            Salary_Details form = new Salary_Details();
            form.Show();
            this.Hide();
        }
    }
}
