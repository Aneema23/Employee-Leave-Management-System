﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project
{
    public partial class Employee : Form
    {
        private string connectionString = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\USER\Desktop\LNBTI\Aneema\Project\Project\Employee Leave Management.mdf; Integrated Security = True;";

        public Employee()
        {
            InitializeComponent();
            
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            string employeeId = txt_id.Text;
            string employeename = txt_name.Text;
            DateTime DOB = dtp_date.Value;
            string address = txt_address.Text;
            string email = txt_email.Text;
            string contactNo = txt_contact.Text.Trim();
            string department = cmd_department.SelectedItem?.ToString();


            // Contact number validation
            if (!Regex.IsMatch(contactNo, @"^\d{10}$"))
            {
                MessageBox.Show("Invalid! Enter 10 digits.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btn_add.Enabled = true; 
                return; // Exit the method if contact number is invalid
            }

            // Validate department selection
            if (string.IsNullOrEmpty(department))
            {
                MessageBox.Show("Please select a department.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                btn_add.Enabled = true;
                return; // Exit if no department is selected
            }


            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                string query = "INSERT INTO Employee (EmployeeID, EmployeeName, Birthday, Address, Email, ContactNo, Department) VALUES (@EmployeeID, @EmployeeName, @Birthday, @Address, @Email, @ContactNo, @Department)";
                SqlCommand cmd = new SqlCommand(query, conn);

                cmd.Parameters.AddWithValue("@EmployeeID", employeeId);
                cmd.Parameters.AddWithValue("@EmployeeName", employeename);
                cmd.Parameters.AddWithValue("@Birthday", DOB);
                cmd.Parameters.AddWithValue("@Address", address);
                cmd.Parameters.AddWithValue("@Email", email);
                cmd.Parameters.AddWithValue("@ContactNo", contactNo);
                cmd.Parameters.AddWithValue("@Department", department);

                conn.Open();
                cmd.ExecuteNonQuery();
            }
            MessageBox.Show("Employee added successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
            btn_add.Enabled = true; 

        }


        private void btn_cancel_Click_1(object sender, EventArgs e)
        {
            txt_id.Text = "";
            txt_name.Text = "";
            dtp_date.Value = DateTime.Now;
            txt_address.Text = "";
            txt_email.Text = "";
            txt_contact.Text = "";
            cmd_department.SelectedIndex = -1;

        }

        private void btn_back_Click_1(object sender, EventArgs e)
        {
            DepartmentHeadDashboard form = new DepartmentHeadDashboard();
            form.Show();
            this.Hide();
        }
    }
}
