﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace Project
{
    public partial class EditEmployee : Form
    {
        private string connectionString = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename = C:\Users\USER\Desktop\LNBTI\Aneema\Project\Project\Employee Leave Management.mdf; Integrated Security = True;";
        private SqlDataAdapter dataAdapter;
        public EditEmployee()
        {
            InitializeComponent();
        }

        private void EditEmployee_Load(object sender, EventArgs e)
        {

        }

        private void btn_search_Click(object sender, EventArgs e)
        {
            string department = cmd_department.SelectedItem?.ToString()?.Trim(); 

            if (string.IsNullOrEmpty(department))
            {
                MessageBox.Show("Please select department.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            LoadData(department);
        }

        private void LoadData(string department = null)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Define the query string based on the department filter.
                    string query = "SELECT * FROM Employee";

                    // Only add the filter if a department is specified.
                    if (!string.IsNullOrEmpty(department))
                    {
                        query += " WHERE Department = @Department";
                    }

                    dataAdapter = new SqlDataAdapter(query, connection);

                    // Add parameter if filtering by department
                    if (!string.IsNullOrEmpty(department))
                    {
                        dataAdapter.SelectCommand.Parameters.AddWithValue("@Department", department);
                    }

                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    // Bind the DataTable to the DataGridView
                    dataGridView1.DataSource = dataTable;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to load data! Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_edit_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a record to edit.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string employeeID = dataGridView1.SelectedRows[0].Cells["EmployeeId"].Value.ToString();
            string employeename = dataGridView1.SelectedRows[0].Cells["EmployeeName"].Value.ToString();
            DateTime dob = Convert.ToDateTime(dataGridView1.SelectedRows[0].Cells["Birthday"].Value);
            string address = dataGridView1.SelectedRows[0].Cells["Address"].Value.ToString();
            string email = dataGridView1.SelectedRows[0].Cells["Email"].Value.ToString();
            string contact = dataGridView1.SelectedRows[0].Cells["ContactNo"].Value.ToString();

            txt_id.Text = employeeID;
            txt_name.Text = employeename;
            dtp_date.Value = dob;
            txt_address.Text = address;
            txt_email.Text = email;
            txt_contact.Text = contact;

            MessageBox.Show("Make changes and click Save to update the record.", "Edit Mode", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btn_save_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(connectionString))
                {
                    connection.Open();

                    // Correct the update query syntax
                    string query = @"UPDATE Employee
                             SET EmployeeName = @EmployeeName, 
                                 Birthday = @Birthday, 
                                 Address = @Address, 
                                 Email = @Email, 
                                 ContactNo = @ContactNo, 
                                 Department = @Department
                             WHERE EmployeeID = @EmployeeID"; // WHERE clause targets specific record

                    using (SqlCommand cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@EmployeeID", txt_id.Text.Trim());
                        cmd.Parameters.AddWithValue("@EmployeeName", txt_name.Text.Trim());
                        cmd.Parameters.AddWithValue("@Birthday", dtp_date.Value);
                        cmd.Parameters.AddWithValue("@Address", txt_address.Text.Trim());
                        cmd.Parameters.AddWithValue("@Email", txt_email.Text.Trim());
                        cmd.Parameters.AddWithValue("@ContactNo", txt_contact.Text.Trim());
                        cmd.Parameters.AddWithValue("@Department", cmd_department.SelectedItem?.ToString().Trim());

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Record updated successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                            // Reload data for the updated employee (optional to show only the updated record)
                            LoadData(txt_id.Text.Trim()); // Pass EmployeeID to reload specific data (or remove filter to load all)
                        }
                        else
                        {
                            MessageBox.Show("No record found to update.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to update record! Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count > 0)
                {
                    string employeeID = dataGridView1.SelectedRows[0].Cells["EmployeeID"].Value.ToString();

                    DialogResult result = MessageBox.Show("Are you sure you want to delete this record?", "Confirmation", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (result == DialogResult.Yes)
                    {
                        using (SqlConnection connection = new SqlConnection(connectionString))
                        {
                            connection.Open();

                            string query = "DELETE FROM Employee WHERE EmployeeID = @EmployeeID";

                            using (SqlCommand cmd = new SqlCommand(query, connection))
                            {
                                cmd.Parameters.AddWithValue("@EmployeeID", employeeID);
                                int rowsAffected = cmd.ExecuteNonQuery();

                                if (rowsAffected > 0)
                                {
                                    MessageBox.Show("Record deleted successfully!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                    // Reload all data after deletion
                                    string department = cmd_department.SelectedItem?.ToString();
                                    LoadData(department); // You can also pass EmployeeID to only reload the specific employee data if needed
                                }
                                else
                                {
                                    MessageBox.Show("Failed to delete record.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                                }
                            }
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please select a record to delete.", "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Failed to delete record! Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btn_cancel_Click(object sender, EventArgs e)
        {
            txt_id.Text = "";
            txt_name.Text = "";
            dtp_date.Value = DateTime.Now;
            txt_address.Text = "";
            txt_email.Text = "";
            txt_contact.Text = "";
            cmd_department.SelectedIndex = -1;
        }

        private void btn_back_Click(object sender, EventArgs e)
        {
            DepartmentHeadDashboard form = new DepartmentHeadDashboard();
            form.Show();
            this.Hide();
        }
    }
}
